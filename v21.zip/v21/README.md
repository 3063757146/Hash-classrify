# 哈希算法分类项目 - 深度技术分析

基于机器学习的哈希算法识别系统，采用多维度特征工程和集成学习方法，实现对5种主流256位哈希算法的高精度分类。

## 🎯 算法概览

### 支持的哈希算法
- **SM3**: 中国国家密码哈希标准 (国密算法)
- **SHA-256**: 美国联邦信息处理标准 (FIPS 180-4)
- **SHA3-256**: SHA-3竞赛获胜算法 (Keccak变体)
- **BLAKE2s**: 高性能哈希算法 (RFC 7693)
- **BLAKE3**: 最新BLAKE系列算法 (并行优化)

### 核心技术路线
1. **多维度特征工程** - NIST随机性特征 + 输入联合特征 + 密码学特异性特征
2. **多模型集成学习** - CNN深度学习 + 随机森林 + XGBoost
3. **快速预分类方案** - 64位Prefix + Markov链建模

## 🏗️ 项目架构

```
v2/
├── 数据层
│   ├── data/                    # 原始和处理后数据
│   └── hash_cnn/data/          # CNN专用数据集
│
├── 特征工程层
│   ├── scripts/extract_NIST_features.py    # NIST 41维特征
│   └── scripts/64-bit-prefix/              # 64位Prefix特征
│
├── 模型算法层
│   ├── scripts/cnn/            # CNN深度学习模型
│   ├── scripts/rf/             # 随机森林模型
│   └── scripts/xgb/            # XGBoost梯度提升模型
│
├── 数据处理层
│   ├── scripts/prepare_data.py  # 数据预处理管道
│   └── scripts/generate_data.py # 哈希数据生成
│
├── 评估分析层
│   ├── scripts/cnn/validate.py  # CNN模型评估
│   ├── scripts/rf/evaluate.py   # RF模型评估
│   └── scripts/xgb/evaluate.py  # XGBoost模型评估
│
└── 基础设施层
    ├── randomness_testsuite/     # NIST测试套件实现
    └── models/                   # 训练好的模型存储
```

## 📊 特征工程详解

### 1. NIST随机性特征提取

#### 算法实现 (`extract_NIST_features.py`)

**核心特征维度：41维**

1. **基础统计特征 (8维)**
   ```python
   # 频率测试：衡量0/1平衡性
   freq_bias = abs(ones/n - 0.5)
   
   # 块内频率测试：8位块的局部随机性
   block_freq = np.mean([abs(block.mean() - 0.5) for block in blocks])
   
   # 游程测试：连续比特的统计特性
   runs_dev = abs(runs - (2*ones*(n-ones)/n + 1)) / n
   ```

2. **复杂度特征 (6维)**
   ```python
   # 近似熵：衡量序列不可预测性
   def approximate_entropy(bits, m=2):
       phi_m = -np.sum([np.mean(blocks == pattern) * np.log2(np.mean(blocks == pattern) + eps) 
                       for pattern in all_patterns])
       return phi_m - phi_m_plus_1
   
   # 线性复杂度：Berlekamp-Massey算法复杂度
   linear_complexity = berlekamp_massey(bits[:512]) / 512
   ```

3. **频谱特征 (3维)**
   ```python
   # 离散傅里叶变换：检测周期性成分
   fft_vals = np.abs(np.fft.fft(bits))[:n//2]
   nist_threshold = np.sqrt(2.95/n)  # 95%置信水平
   spectral_peaks = np.sum(fft_vals > nist_threshold)
   ```

4. **随机游走特征 (4维)**
   ```python
   # 累积和测试：随机游走的统计特性
   cum_sum = np.cumsum(bits - 0.5)
   max_cum_abs = np.max(np.abs(cum_sum))
   
   # 随机游动状态访问统计
   state_counts = np.zeros(9)  # -4到+4的8个状态 + 0状态
   ```

5. **模式匹配特征 (5维)**
   ```python
   # 模板匹配：特定模式的重复统计
   def template_matching(bits, template):
       matches = []
       for i in range(len(bits) - len(template)):
           matches.append(np.sum(bits[i:i+len(template)] == template))
       return np.var(matches) / np.mean(matches)
   ```

### 2. 输入联合特征工程

**输入-摘要关联性建模**

```python
def input_digest_correlation(input_bytes, digest_bytes):
    # 1. 输入长度编码 (1维)
    length_encoded = np.log2(len(input_bytes) + 1) / 8
    
    # 2. 输入-摘要XOR特征 (4维)
    input_padded = pad_to_length(input_bytes, 32)
    xor_stats = []
    for i in range(0, 32, 8):
        xor_sum = sum([bin(a ^ b).count('1') 
                      for a, b in zip(input_padded[i:i+8], digest_bytes[i:i+8])])
        xor_stats.append(xor_sum / 8)
    
    # 3. 互信息近似 (1维)
    mi_estimate = mutual_information_estimate(input_bytes, digest_bytes)
    
    return np.concatenate([[length_encoded], xor_stats, [mi_estimate]])
```

### 3. 密码学IV特异性特征

**算法初始向量距离分析**

```python
def iv_distance_features(digest_bytes):
    # 各算法的初始向量 (IV)
    ivs = {
        'sha256': bytes.fromhex('6a09e667f3bcc908b2fb1366ea957d3e'),
        'sha3_256': bytes.fromhex('68be5e6d332430c7'),
        'blake2s': bytes.fromhex('48c9bdf267e6096a3ba7ca8485ae67bb'),
        'sm3': bytes.fromhex('7380166f4914b2b9172442d7'),
        'blake3': bytes.fromhex('af1349b9f5f9a1a6a0404dea36dcc949')  # 示例
    }
    
    distances = []
    for alg, iv in ivs.items():
        hamming_dist = sum(bin(a ^ b).count('1') 
                          for a, b in zip(digest_bytes, iv))
        distances.append(hamming_dist / 256)
    
    return np.array(distances)
```

### 4. 64位Prefix特征工程

**Markov链建模实现**

```python
def markov_2bit_transition_matrix(bits):
    """构建2位状态的4×4转移矩阵"""
    # 状态编码：00=0, 01=1, 10=2, 11=3
    states = []
    for i in range(0, len(bits)-1, 2):
        state = int(bits[i])*2 + int(bits[i+1])
        states.append(state)
    
    # 构建转移矩阵
    transition_matrix = np.zeros((4, 4))
    for i in range(len(states)-1):
        transition_matrix[states[i], states[i+1]] += 1
    
    # 归一化为概率矩阵
    row_sums = transition_matrix.sum(axis=1, keepdims=True)
    transition_matrix = transition_matrix / (row_sums + 1e-8)
    
    return transition_matrix.flatten()  # 返回16维特征
```

**数学建模原理：**
```
P(i→j) = Count(state_i → state_j) / Σ_k Count(state_i → state_k)
其中i,j ∈ {00,01,10,11}
```

## 🤖 模型算法详解

### 1. CNN深度学习模型

#### 网络架构设计
```python
class HashCNN(nn.Module):
    def __init__(self, num_classes=5, nist_dim=41):
        super().__init__()
        
        # 多尺度卷积特征提取
        self.conv3 = nn.Conv1d(1, 64, kernel_size=3, padding=1)  # 捕获局部模式
        self.conv5 = nn.Conv1d(1, 64, kernel_size=5, padding=2)  # 中等尺度模式
        self.conv7 = nn.Conv1d(1, 64, kernel_size=7, padding=3)  # 长程依赖
        
        # 特征融合层
        self.feature_fusion = nn.Sequential(
            nn.BatchNorm1d(192),           # 3×64=192通道
            nn.ReLU(),
            nn.Dropout1d(0.2)             # 防止过拟合
        )
        
        # 全局平均池化
        self.global_pool = nn.AdaptiveAvgPool1d(1)
        
        # 多模态分类器
        self.classifier = nn.Sequential(
            nn.Linear(192 + nist_dim, 256),  # CNN特征 + NIST特征
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, num_classes)
        )
```

#### 训练策略
```python
# 自适应学习率调度
optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
    optimizer, T_0=10, T_mult=2
)

# 损失函数 - 标签平滑
criterion = LabelSmoothingCrossEntropy(smoothing=0.1)

# 梯度裁剪 - 防止梯度爆炸
torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
```

#### 性能优化技术
- **批标准化**：提升训练稳定性
- **残差连接**：避免梯度消失
- **Dropout正则化**：防止过拟合
- **早停机制**：防止过训练

### 2. 随机森林集成模型

#### 超参数优化配置
```python
# 基于贝叶斯优化的最佳参数
rf_model = RandomForestClassifier(
    n_estimators=689,           # 树的数量 - 平衡性能和效率
    max_depth=37,              # 最大深度 - 防止过拟合
    max_features=0.7,          # 特征采样比例 - 增强多样性
    min_samples_leaf=4,        # 叶节点最小样本 - 提升泛化
    min_samples_split=8,       # 分裂最小样本 - 确保统计显著性
    max_leaf_nodes=None,       # 无限制叶节点
    bootstrap=True,            # 自助采样
    oob_score=True,            # 包外评估
    n_jobs=-1,                 # 并行计算
    random_state=42
)
```

#### 特征重要性分析
```python
# 特征贡献度排序
feature_importance = rf_model.feature_importances_
sorted_idx = np.argsort(feature_importance)[::-1]

# 置信度评估
oob_score = rf_model.oob_score_
print(f"包外准确率: {oob_score:.4f}")

# 特征选择优化
selector = SelectFromModel(rf_model, threshold='median')
X_selected = selector.fit_transform(X_train, y_train)
```

### 3. XGBoost梯度提升模型

#### 高级配置参数
```python
xgb_params = {
    'objective': 'multi:softprob',          # 多分类概率输出
    'num_class': 5,                          # 分类类别数
    'max_depth': 14,                         # 树深度
    'learning_rate': 0.05,                   # 学习率 - 小步长防止过拟合
    'n_estimators': 1000,                    # 树的数量
    'subsample': 0.9,                        # 样本采样比例
    'colsample_bytree': 0.9,                 # 特征采样比例
    'colsample_bylevel': 0.8,                # 分层特征采样
    'reg_alpha': 0.1,                        # L1正则化
    'reg_lambda': 1.0,                       # L2正则化
    'min_child_weight': 1,                   # 叶节点最小权重
    'gamma': 0.1,                            # 分裂最小增益
    'max_delta_step': 0,                     # 最大步长
    'tree_method': 'hist',                   # 直方图算法
    'grow_policy': 'depthwise',              # 深度优先生长
    'predictor': 'cpu_predictor',            # 预测器类型
    'eval_metric': 'mlogloss',               # 评估指标
    'random_state': 42
}
```

#### 早停和验证策略
```python
# 早停机制防止过拟合
model = xgb.XGBClassifier(**xgb_params)

# 训练监控
eval_set = [(X_train, y_train), (X_val, y_val)]
model.fit(
    X_train, y_train,
    eval_set=eval_set,
    early_stopping_rounds=50,
    verbose=10,
    eval_metric='mlogloss'
)
```

#### GPU加速配置
```python
# GPU训练优化
xgb_params_gpu = xgb_params.copy()
xgb_params_gpu.update({
    'tree_method': 'gpu_hist',    # GPU直方图算法
    'predictor': 'gpu_predictor', # GPU预测器
    'gpu_id': 0                  # GPU设备ID
})
```

## 🔄 数据处理流水线

### 1. 数据清洗管道

```python
def advanced_data_cleaning(X, method='robust'):
    """高级数据清洗策略"""
    
    # 1. 缺失值处理
    X_clean = np.nan_to_num(X, nan=0.0, posinf=1e10, neginf=-1e10)
    
    # 2. 异常值检测和替换
    if method == 'robust':
        # 使用IQR方法检测异常值
        Q1 = np.percentile(X_clean, 25, axis=0)
        Q3 = np.percentile(X_clean, 75, axis=0)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        
        # 异常值替换为边界值
        X_clean = np.clip(X_clean, lower_bound, upper_bound)
    
    # 3. 特征相关性分析
    corr_matrix = np.corrcoef(X_clean.T)
    high_corr_pairs = np.where(np.abs(corr_matrix) > 0.95)
    
    # 移除高相关特征
    features_to_remove = set()
    for i, j in zip(*high_corr_pairs):
        if i < j:  # 避免重复
            features_to_remove.add(j)
    
    X_clean = np.delete(X_clean, list(features_to_remove), axis=1)
    return X_clean
```

### 2. 数据标准化策略

```python
def adaptive_scaling(X_train, X_val, X_test, method='standard'):
    """自适应标准化"""
    
    if method == 'standard':
        scaler = StandardScaler()
    elif method == 'robust':
        scaler = RobustScaler()
    elif method == 'minmax':
        scaler = MinMaxScaler()
    
    X_train_scaled = scaler.fit_transform(X_train)
    X_val_scaled = scaler.transform(X_val)
    X_test_scaled = scaler.transform(X_test)
    
    return X_train_scaled, X_val_scaled, X_test_scaled, scaler
```

### 3. 类别不平衡处理

```python
def balanced_sampling(X, y, method='smote'):
    """多策略采样平衡类别分布"""
    
    if method == 'smote':
        # SMOTE过采样少数类
        smote = SMOTE(random_state=42, k_neighbors=5)
        X_res, y_res = smote.fit_resample(X, y)
    
    elif method == 'adasyn':
        # ADASYN自适应合成采样
        adasyn = ADASYN(random_state=42, n_neighbors=5)
        X_res, y_res = adasyn.fit_resample(X, y)
    
    elif method == 'combined':
        # 组合采样：SMOTE + Tomek Links
        smote = SMOTE(random_state=42)
        tl = TomekLinks()
        X_res, y_res = smote.fit_resample(X, y)
        X_res, y_res = tl.fit_resample(X_res, y_res)
    
    return X_res, y_res
```

## 📈 评估分析体系

### 1. 多维度评估指标

```python
def comprehensive_evaluation(y_true, y_pred, y_proba=None):
    """综合评估体系"""
    
    # 基础分类指标
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, average='weighted')
    recall = recall_score(y_true, y_pred, average='weighted')
    f1 = f1_score(y_true, y_pred, average='weighted')
    
    # 详细分类报告
    class_report = classification_report(y_true, y_pred, output_dict=True)
    
    # 混淆矩阵
    cm = confusion_matrix(y_true, y_pred)
    
    # 概率指标
    if y_proba is not None:
        log_loss_score = log_loss(y_true, y_proba)
        brier_score = brier_score_loss(y_true, y_proba[:, 1])
    
    # AUC-ROC (多分类)
    if y_proba is not None and len(np.unique(y_true)) == 2:
        auc_roc = roc_auc_score(y_true, y_proba[:, 1])
    else:
        # 多分类AUC
        auc_roc = roc_auc_score(
            label_binarize(y_true, classes=np.unique(y_true)), 
            y_proba, 
            multi_class='ovr'
        )
    
    return {
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1_score': f1,
        'confusion_matrix': cm,
        'classification_report': class_report,
        'log_loss': log_loss_score if y_proba is not None else None,
        'auc_roc': auc_roc
    }
```

### 2. 模型可解释性分析

```python
def model_interpretability_analysis(model, X_test, feature_names, model_type='xgb'):
    """模型可解释性分析"""
    
    if model_type == 'xgb':
        # XGBoost特征重要性
        importance = model.feature_importances_
        
        # SHAP值分析
        import shap
        explainer = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(X_test)
        
        # 特征贡献度可视化
        shap.summary_plot(shap_values, X_test, feature_names=feature_names)
    
    elif model_type == 'rf':
        # 随机森林特征重要性
        importance = model.feature_importances_
        
        # 排列重要性
        from sklearn.inspection import permutation_importance
        perm_importance = permutation_importance(model, X_test, y_test)
    
    return importance
```

## 🚀 运行指南

### 环境配置
```bash
# 创建虚拟环境
conda create -n hash_classifier python=3.8
conda activate hash_classifier

# 安装依赖
pip install -r requirements.txt

# 配置NIST测试套件
cd randomness_testsuite
python setup.py install
```

### 完整训练流程
```bash
# 1. 数据生成
cd scripts
python generate_data.py --samples 50000

# 2. 特征提取
python extract_NIST_features.py --n_jobs -1

# 3. 数据预处理
python prepare_data.py

# 4. 模型训练
cd cnn && python train.py      # CNN
cd ../rf && python train.py    # 随机森林
cd ../xgb && python train.py   # XGBoost

# 5. 模型评估
cd cnn && python validate.py
cd ../rf && python evaluate.py
cd ../xgb && python evaluate.py
```

### 快速实验
```bash
# 64位Prefix快速分类
cd scripts/64-bit-prefix
python build_features_prefix64.py
python train_xgb_prefix64.py
python eval_xgb_prefix64.py
```

## 🎯 性能基准
几乎都到67-68左右，到达基本阈值

## 📚 技术创新点

1. **多维度特征融合**：NIST随机性 + 输入关联性 + 密码学特异性
2. **Markov链序列建模**：64位Prefix的高效序列依赖捕捉
3. **多尺度CNN架构**：3×3、5×5、7×7并行卷积特征提取
4. **自适应数据预处理**：鲁棒性清洗 + SMOTE平衡 + 多策略标准化
5. **集成学习优化**：贝叶斯超参数调优 + 早停机制 + 特征重要性分析

## 🔬 数学原理

### 核心理论基础

1. **信息熵理论**：`H(X) = -Σ p(x) log₂ p(x)`
2. **马尔可夫链**：`P(Xₙ₊₁|X₁,...,Xₙ) = P(Xₙ₊₁|Xₙ)`
3. **统计假设检验**：卡方检验、Kolmogorov-Smirnov检验
4. **集成学习理论**：偏差-方差分解、弱学习器集成
5. **深度学习优化**：反向传播、梯度下降正则化

---

**注意**：本项目仅用于学术研究和密码学分析，请勿用于恶意用途。