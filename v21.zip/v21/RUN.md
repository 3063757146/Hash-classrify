# 哈希算法分类实验

本项目是一个基于机器学习的哈希算法分类实验，旨在通过分析哈希摘要的特征来识别其使用的哈希算法。

## 项目概述

本实验使用Python实现对以下五种256位哈希算法的分类：
- SM3
- SHA-256
- SHA3-256
- BLAKE2s
- BLAKE3

通过提取哈希摘要的多维度特征，使用机器学习模型进行训练和分类，最终实现较高的分类准确率。

## 项目结构

```
哈希摘要分类/
├── data/              # 数据存储目录
├── models/            # 模型保存目录
├── results/           # 结果图表目录
├── scripts/           # 各阶段脚本目录
├── randomness_testsuite/  # 随机性测试套件
└── README.md
```

## 环境要求

- Python 3.8 或更高版本
- 依赖库：
  - numpy
  - scipy
  - scikit-learn
  - joblib
  - matplotlib
  - seaborn
  - pandas
  - gmssl
  - blake3
  - pywavelets
  - tqdm
  - imbalanced-learn
  - xgboost

## 运行步骤

1. **环境配置**
   ```bash
   python scripts/setup.py
   ```

2. **数据生成**
   ```bash
   python scripts/generate_data.py
   ```

3. **特征提取**
   ```bash
   python scripts/extract_NIST_features.py
   ```

4. **数据集准备**
   
   ```bash
   python scripts/prepare_data.py
   ```
   
5. **模型训练**
   
   ```bash
   python scripts/xxx/train_model.py
   ```
   
6. **评估分析**
   
   ```bash
   python scripts/xxx/evaluate.py
   ```



