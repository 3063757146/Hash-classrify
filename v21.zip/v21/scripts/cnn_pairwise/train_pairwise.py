# train_pairwise.py
# Pairwise Hash Algorithm Classification (Binary)
# CNN (bit-level) + Compact NIST features
# SAVE MODEL VERSION ✅

import argparse
import pickle
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, random_split
from sklearn.metrics import classification_report, accuracy_score
import os

# =========================
# 配置
# =========================
DATA_PATH = "./hash_dataset.pkl"
BATCH_SIZE = 128
EPOCHS = 20
LR = 1e-3
VAL_SPLIT = 0.2
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

MODEL_DIR = "./models_pairwise"
os.makedirs(MODEL_DIR, exist_ok=True)

# =========================
# 简化 NIST 特征（稳定版）
# =========================
def extract_nist_compact(digest_bin: str):
    n = len(digest_bin)
    if n == 0:
        return np.zeros(8, dtype=np.float32)

    ones = digest_bin.count("1")
    zeros = n - ones
    freq_bias = abs(ones / n - 0.5)

    block_size = 8
    blocks = [digest_bin[i:i+block_size] for i in range(0, n, block_size)]
    block_ones = [b.count("1") for b in blocks if len(b) == block_size]
    block_bias = abs(np.mean(block_ones) / block_size - 0.5) if block_ones else 0.0

    runs = sum(digest_bin[i] != digest_bin[i-1] for i in range(1, n)) + 1
    runs_exp = 2 * ones * zeros / n + 1
    runs_dev = abs(runs - runs_exp) / n

    longest_run = max(len(s) for s in digest_bin.split("0"))
    cs = np.cumsum([1 if b == "1" else -1 for b in digest_bin])
    cum_forward = np.max(np.abs(cs)) / n
    cs_rev = np.cumsum([1 if b == "1" else -1 for b in digest_bin[::-1]])
    cum_backward = np.max(np.abs(cs_rev)) / n

    entropy = -(ones/n)*np.log2(ones/n + 1e-8) - (zeros/n)*np.log2(zeros/n + 1e-8)

    return np.array([
        freq_bias,
        block_bias,
        runs_dev,
        longest_run / 32,
        cum_forward,
        cum_backward,
        entropy,
        ones / n
    ], dtype=np.float32)

# =========================
# 工具函数
# =========================
def bytes_to_binary(b: bytes):
    return ''.join(f'{x:08b}' for x in b)

def ensure_bytes(x):
    if isinstance(x, bytes):
        return x
    if isinstance(x, str):
        if x.startswith("b'") or x.startswith('b"'):
            return eval(x)
        return bytes.fromhex(x)
    return None

# =========================
# Dataset
# =========================
class PairwiseHashDataset(Dataset):
    def __init__(self, path, alg1, alg2):
        with open(path, "rb") as f:
            data = pickle.load(f)

        self.X_bin, self.X_feat, self.y = [], [], []

        for _, row in data.iterrows():
            algo = row["algorithm"]
            if algo not in (alg1, alg2):
                continue

            digest_bin = row.get("digest_bin")
            if not isinstance(digest_bin, str):
                try:
                    digest_bin = bytes_to_binary(ensure_bytes(row["digest_bytes"]))
                except:
                    continue

            digest_bin = digest_bin[:256]
            if len(digest_bin) < 256:
                continue

            self.X_bin.append(
                np.fromiter((int(b) for b in digest_bin), dtype=np.float32)
            )
            self.X_feat.append(extract_nist_compact(digest_bin))
            self.y.append(0 if algo == alg1 else 1)

        if len(self.y) == 0:
            raise RuntimeError("❌ No samples loaded")

        self.X_bin = np.stack(self.X_bin)
        self.X_feat = np.stack(self.X_feat)
        self.y = np.array(self.y, dtype=np.int64)

        print(f"[INFO] Loaded {len(self.y)} samples ({alg1}=0, {alg2}=1)")

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        return (
            torch.tensor(self.X_bin[idx].reshape(1, 256)),
            torch.tensor(self.X_feat[idx]),
            torch.tensor(self.y[idx])
        )

# =========================
# Model
# =========================
class BinaryHashCNN(nn.Module):
    def __init__(self, feat_dim):
        super().__init__()
        self.conv3 = nn.Conv1d(1, 64, 3, padding=1)
        self.conv5 = nn.Conv1d(1, 64, 5, padding=2)
        self.conv7 = nn.Conv1d(1, 64, 7, padding=3)

        self.bn = nn.BatchNorm1d(192)
        self.relu = nn.ReLU()
        self.gap = nn.AdaptiveAvgPool1d(1)

        self.fc1 = nn.Linear(192 + feat_dim, 64)
        self.fc2 = nn.Linear(64, 2)

    def forward(self, x_bin, x_feat):
        x = torch.cat([
            self.conv3(x_bin),
            self.conv5(x_bin),
            self.conv7(x_bin)
        ], dim=1)

        x = self.relu(self.bn(x))
        x = self.gap(x).squeeze(-1)
        x = torch.cat([x, x_feat], dim=1)
        x = self.relu(self.fc1(x))
        return self.fc2(x)

# =========================
# Train
# =========================
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--alg1", required=True)
    parser.add_argument("--alg2", required=True)
    args = parser.parse_args()

    dataset = PairwiseHashDataset(DATA_PATH, args.alg1, args.alg2)
    val_size = int(len(dataset) * VAL_SPLIT)
    train_set, val_set = random_split(dataset, [len(dataset)-val_size, val_size])

    train_loader = DataLoader(train_set, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_set, batch_size=BATCH_SIZE)

    model = BinaryHashCNN(feat_dim=8).to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    criterion = nn.CrossEntropyLoss()

    best_acc = 0.0

    for epoch in range(EPOCHS):
        model.train()
        for xb, xf, y in train_loader:
            xb, xf, y = xb.to(DEVICE), xf.to(DEVICE), y.to(DEVICE)
            optimizer.zero_grad()
            loss = criterion(model(xb, xf), y)
            loss.backward()
            optimizer.step()

        model.eval()
        preds, labels = [], []
        with torch.no_grad():
            for xb, xf, y in val_loader:
                logits = model(xb.to(DEVICE), xf.to(DEVICE))
                preds.extend(logits.argmax(1).cpu().numpy())
                labels.extend(y.numpy())

        acc = accuracy_score(labels, preds)
        print(f"Epoch {epoch+1:02d} | Val Acc: {acc:.4f}")

        # ✅ 保存最优模型
        if acc > best_acc:
            best_acc = acc
            save_path = f"{MODEL_DIR}/{args.alg1}_vs_{args.alg2}.pt"
            torch.save({
                "model_state": model.state_dict(),
                "alg1": args.alg1,
                "alg2": args.alg2,
                "feat_dim": 8
            }, save_path)
            print(f"💾 Saved best model to {save_path}")

    print("\nFinal Classification Report:")
    print(classification_report(labels, preds, target_names=[args.alg1, args.alg2]))
    print(f"🏁 Best Val Acc: {best_acc:.4f}")

if __name__ == "__main__":
    main()
