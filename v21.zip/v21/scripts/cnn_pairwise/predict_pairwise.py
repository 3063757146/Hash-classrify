# predict_pairwise.py
import torch
import pickle
import numpy as np
import itertools
from collections import defaultdict
from train_pairwise import BinaryHashCNN, extract_nist_compact, bytes_to_binary

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

ALGS = ["sha256", "sha3_256", "sm3", "blake2s", "blake3"]
MODEL_DIR = "./models_pairwise"

def load_model(a, b):
    path = f"{MODEL_DIR}/{a}_vs_{b}.pt"
    model = BinaryHashCNN(feat_dim=8)
    model.load_state_dict(torch.load(path, map_location=DEVICE))
    model.to(DEVICE)
    model.eval()
    return model

def predict_single(digest_bytes):
    votes = defaultdict(int)
    digest_bin = bytes_to_binary(digest_bytes)[:256]

    bits = torch.tensor(
        np.fromiter((int(b) for b in digest_bin), dtype=np.float32)
    ).reshape(1, 1, 256).to(DEVICE)

    feats = torch.tensor(
        extract_nist_compact(digest_bin)
    ).unsqueeze(0).to(DEVICE)

    for a, b in itertools.combinations(ALGS, 2):
        model = load_model(a, b)
        out = model(bits, feats)
        pred = out.argmax(1).item()
        votes[a if pred == 0 else b] += 1

    return dict(votes)

if __name__ == "__main__":
    # 示例
    test = b"example message"
    import hashlib
    d = hashlib.sha256(test).digest()

    print(predict_single(d))
