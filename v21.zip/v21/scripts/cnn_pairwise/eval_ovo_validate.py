# eval_ovo_validate.py
# OvO (One-vs-One) VALIDATION Evaluation Script
# Evaluate all pairwise binary CNN models on validate.pkl

import os
import pickle
import torch
import torch.nn as nn
import numpy as np
from collections import Counter
from sklearn.metrics import classification_report, accuracy_score
from torch.utils.data import Dataset, DataLoader

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

VAL_PATH = "./hash_dataset.pkl"
MODEL_DIR = "./models_pairwise"
BATCH_SIZE = 256

# =========================
# Compact NIST features (MUST match training)
# =========================
def extract_nist_compact(digest_bin: str):
    n = len(digest_bin)
    if n == 0:
        return np.zeros(8, dtype=np.float32)

    ones = digest_bin.count("1")
    zeros = n - ones
    freq_bias = abs(ones / n - 0.5)

    block_size = 8
    blocks = [digest_bin[i:i+block_size] for i in range(0, n, block_size)]
    block_ones = [b.count("1") for b in blocks if len(b) == block_size]
    block_bias = abs(np.mean(block_ones) / block_size - 0.5) if block_ones else 0.0

    runs = sum(digest_bin[i] != digest_bin[i-1] for i in range(1, n)) + 1
    runs_exp = 2 * ones * zeros / n + 1
    runs_dev = abs(runs - runs_exp) / n

    longest_run = max(len(s) for s in digest_bin.split("0"))

    cs = np.cumsum([1 if b == "1" else -1 for b in digest_bin])
    cum_forward = np.max(np.abs(cs)) / n
    cs_rev = np.cumsum([1 if b == "1" else -1 for b in digest_bin[::-1]])
    cum_backward = np.max(np.abs(cs_rev)) / n

    entropy = -(ones/n)*np.log2(ones/n + 1e-8) - (zeros/n)*np.log2(zeros/n + 1e-8)

    return np.array([
        freq_bias,
        block_bias,
        runs_dev,
        longest_run / 32,
        cum_forward,
        cum_backward,
        entropy,
        ones / n
    ], dtype=np.float32)

# =========================
# Utils
# =========================
def bytes_to_binary(b: bytes):
    return ''.join(f'{x:08b}' for x in b)

def ensure_bytes(x):
    if isinstance(x, bytes):
        return x
    if isinstance(x, str):
        if x.startswith("b'") or x.startswith('b"'):
            return eval(x)
        return bytes.fromhex(x)
    return None

# =========================
# Validation Dataset
# =========================
class ValidateDataset(Dataset):
    def __init__(self, path):
        with open(path, "rb") as f:
            data = pickle.load(f)

        self.X_bin = []
        self.X_feat = []
        self.y = []

        for _, row in data.iterrows():
            algo = row["algorithm"]
            digest_bin = row.get("digest_bin")

            if not isinstance(digest_bin, str):
                try:
                    digest_bin = bytes_to_binary(ensure_bytes(row["digest_bytes"]))
                except:
                    continue

            digest_bin = digest_bin[:256]
            if len(digest_bin) < 256:
                continue

            self.X_bin.append(
                np.fromiter((int(b) for b in digest_bin), dtype=np.float32)
            )
            self.X_feat.append(extract_nist_compact(digest_bin))
            self.y.append(algo)

        self.X_bin = np.stack(self.X_bin)
        self.X_feat = np.stack(self.X_feat)
        self.y = np.array(self.y)

        print(f"[INFO] Validation samples loaded: {len(self.y)}")

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        return (
            torch.tensor(self.X_bin[idx].reshape(1, 256)),
            torch.tensor(self.X_feat[idx]),
            self.y[idx]
        )

# =========================
# CNN Model (same as training)
# =========================
class BinaryHashCNN(nn.Module):
    def __init__(self, feat_dim):
        super().__init__()
        self.conv3 = nn.Conv1d(1, 64, 3, padding=1)
        self.conv5 = nn.Conv1d(1, 64, 5, padding=2)
        self.conv7 = nn.Conv1d(1, 64, 7, padding=3)

        self.bn = nn.BatchNorm1d(192)
        self.relu = nn.ReLU()
        self.gap = nn.AdaptiveAvgPool1d(1)

        self.fc1 = nn.Linear(192 + feat_dim, 64)
        self.fc2 = nn.Linear(64, 2)

    def forward(self, x_bin, x_feat):
        x = torch.cat([
            self.conv3(x_bin),
            self.conv5(x_bin),
            self.conv7(x_bin)
        ], dim=1)

        x = self.relu(self.bn(x))
        x = self.gap(x).squeeze(-1)
        x = torch.cat([x, x_feat], dim=1)
        x = self.relu(self.fc1(x))
        return self.fc2(x)

# =========================
# Load Pairwise Models
# =========================
def load_pairwise_models():
    models = []
    for fname in os.listdir(MODEL_DIR):
        if not fname.endswith(".pt"):
            continue

        ckpt = torch.load(os.path.join(MODEL_DIR, fname), map_location=DEVICE)
        model = BinaryHashCNN(feat_dim=ckpt["feat_dim"]).to(DEVICE)
        model.load_state_dict(ckpt["model_state"])
        model.eval()

        models.append((model, ckpt["alg1"], ckpt["alg2"]))
        print(f"[LOAD] {ckpt['alg1']} vs {ckpt['alg2']}")

    print(f"[INFO] Loaded {len(models)} OvO models")
    return models

# =========================
# OvO Validation
# =========================
def main():
    dataset = ValidateDataset(VAL_PATH)
    loader = DataLoader(dataset, batch_size=BATCH_SIZE)

    models = load_pairwise_models()

    y_true = []
    y_pred = []

    with torch.no_grad():
        for xb, xf, labels in loader:
            xb = xb.to(DEVICE)
            xf = xf.to(DEVICE)

            for i in range(len(labels)):
                votes = Counter()
                for model, alg1, alg2 in models:
                    out = model(xb[i:i+1], xf[i:i+1])
                    pred = out.argmax(1).item()
                    votes[alg1 if pred == 0 else alg2] += 1

                final_pred = votes.most_common(1)[0][0]
                y_pred.append(final_pred)
                y_true.append(labels[i])

    print("\n=== OvO Validation Classification Report ===")
    print(classification_report(y_true, y_pred))
    print("Overall Accuracy:", accuracy_score(y_true, y_pred))

if __name__ == "__main__":
    main()
