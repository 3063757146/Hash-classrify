#!/bin/bash
# ============================
# Train all pairwise classifiers
# ============================

ALGS=(
  "sha256"
  "sha3_256"
  "sm3"
  "blake2s"
  "blake3"
)

LOG_DIR="logs_pairwise"
MODEL_DIR="models_pairwise"

mkdir -p ${LOG_DIR}
mkdir -p ${MODEL_DIR}

for ((i=0; i<${#ALGS[@]}; i++)); do
  for ((j=i+1; j<${#ALGS[@]}; j++)); do
    A=${ALGS[i]}
    B=${ALGS[j]}
    NAME="${A}_vs_${B}"

    echo "🔥 Training ${NAME}"

    python train_pairwise.py \
      --alg1 ${A} \
      --alg2 ${B} \
      2>&1 | tee ${LOG_DIR}/${NAME}.log

  done
done

echo "✅ All pairwise training finished."
