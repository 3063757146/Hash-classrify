# scripts/xgb/evaluate.py
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
from joblib import load
import numpy as np
import argparse

# 解析命令行参数
parser = argparse.ArgumentParser(description='XGBoost模型评估脚本')
parser.add_argument('--features', type=int, nargs='*', 
                    help='评估时使用的特征索引列表，需要与训练时使用的特征保持一致')
args = parser.parse_args()

# 加载测试数据
X_test = np.load('../../data/X_test.npy')
y_test = np.load('../../data/y_test.npy')
ALGORITHMS = ['sm3', 'sha256', 'sha3_256', 'blake2s', 'blake3']

# 加载模型
print("加载XGBoost模型...")
model = load('../../models/xgb_model.joblib')

# 处理特征选择
if args.features is not None:
    print(f"使用特征索引: {args.features}")
    X_test = X_test[:, args.features]

# 预测
y_pred = model.predict(X_test)
print(classification_report(y_test, y_pred, target_names=ALGORITHMS, zero_division=0))

# 混淆矩阵
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(8,6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=ALGORITHMS, yticklabels=ALGORITHMS)
plt.title('Confusion Matrix (XGB)')
plt.ylabel('True Label')
plt.xlabel('Predicted Label')
plt.savefig('./results/confusion_matrix_xgb.png')
plt.close()

# 特征重要性
importances = model.feature_importances_
# 根据实际特征数量调整显示的特征数
n_features = len(importances)
top_n = min(20, n_features)
top_idx = np.argsort(importances)[-top_n:]
plt.figure(figsize=(10,6))
plt.barh(range(top_n), importances[top_idx])
plt.yticks(range(top_n), [f'Feature {i}' for i in top_idx])
plt.title('Top 20 Important Features (XGB)')
plt.tight_layout()
plt.savefig('./results/feature_importance_xgb.png')
plt.close()

# 各类别准确率
print("\n各类别准确率:")
for i, alg in enumerate(ALGORITHMS):
    mask = (y_test == i)
    if np.sum(mask) > 0:
        acc = np.sum((y_test == i) & (y_pred == i)) / np.sum(mask)
        print(f"{alg}: {acc:.4f}")

print("XGBoost评估完成! 结果已保存到results目录")