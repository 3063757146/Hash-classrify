import pickle
import numpy as np
import os
from tqdm import tqdm

# =========================
DATA_PKL = "validate.pkl"
OUT_DIR = "features"
WINDOW = 16
STEP = 4
ALGOS = ["sha256", "sha3_256", "sm3", "blake2s", "blake3"]

os.makedirs(OUT_DIR, exist_ok=True)

# =========================
def shannon_entropy(bits):
    n = len(bits)
    if n == 0:
        return 0.0
    p1 = bits.sum() / n
    p0 = 1 - p1
    ent = 0
    if p1 > 0:
        ent -= p1 * np.log2(p1)
    if p0 > 0:
        ent -= p0 * np.log2(p0)
    return ent

def run_count(bits):
    return np.sum(bits[1:] != bits[:-1]) + 1

def max_run_ones(bits):
    max_run, cur = 0, 0
    for b in bits:
        if b == 1:
            cur += 1
            max_run = max(max_run, cur)
        else:
            cur = 0
    return max_run

def extract_sliding_features(bits, window=16, step=4):
    feats = []
    n = len(bits)
    for i in range(0, n - window + 1, step):
        w = bits[i:i + window]
        feats.extend([
            shannon_entropy(w),
            w.mean(),
            run_count(w) / window,
            max_run_ones(w) / window
        ])
    return feats

# =========================
def main():
    with open(DATA_PKL, "rb") as f:
        data = pickle.load(f)

    algo2id = {a: i for i, a in enumerate(ALGOS)}

    X, y = [], []

    for _, row in tqdm(data.iterrows(), total=len(data)):
        algo = row["algorithm"]
        if algo not in algo2id:
            continue

        digest_bin = row.get("digest_bin")
        if not isinstance(digest_bin, str) or len(digest_bin) < 256:
            continue

        bits = np.fromiter(
            (int(b) for b in digest_bin[:256]),
            dtype=np.float32
        )

        X.append(extract_sliding_features(bits, WINDOW, STEP))
        y.append(algo2id[algo])

    X = np.array(X, dtype=np.float32)
    y = np.array(y, dtype=np.int64)

    np.save(os.path.join(OUT_DIR, "X_test.npy"), X)
    np.save(os.path.join(OUT_DIR, "y_test.npy"), y)

    print(f"[DONE] Saved X {X.shape}, y {y.shape}")

if __name__ == "__main__":
    main()
