import numpy as np
import pickle
import xgboost as xgb
from sklearn.model_selection import train_test_split

ALGOS = ["sha256", "sha3_256", "sm3", "blake2s", "blake3"]

X = np.load("features/X.npy", mmap_mode="r")
y = np.load("features/y.npy")

X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

model = xgb.XGBClassifier(
    n_estimators=500,
    max_depth=6,
    learning_rate=0.05,
    subsample=0.9,
    colsample_bytree=0.9,
    tree_method="hist",
    objective="multi:softmax",
    num_class=len(ALGOS)
)

model.fit(X_train, y_train)

with open("xgb_sliding.pkl", "wb") as f:
    pickle.dump(model, f)

print("[DONE] Model saved")
