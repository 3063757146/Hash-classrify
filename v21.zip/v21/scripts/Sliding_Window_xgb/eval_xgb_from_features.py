import numpy as np
import pickle
from sklearn.metrics import classification_report, accuracy_score

ALGOS = ["sha256", "sha3_256", "sm3", "blake2s", "blake3"]

X = np.load("features/X_test.npy", mmap_mode="r")
y = np.load("features/y_test.npy")

with open("xgb_sliding.pkl", "rb") as f:
    model = pickle.load(f)

preds = model.predict(X)

print("Accuracy:", accuracy_score(y, preds))
print(classification_report(y, preds, target_names=ALGOS))
