# scripts/prepare_data.py
import numpy as np
import pandas as pd
import argparse
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.impute import SimpleImputer

try:
    from imblearn.over_sampling import SMOTE
    SMOTE_AVAILABLE = True
except ImportError:
    SMOTE_AVAILABLE = False
    print("未安装 imbalanced-learn，SMOTE 将被禁用")

def clean_features(X: np.ndarray, method: str = 'zero') -> np.ndarray:
    X = np.nan_to_num(X, nan=0.0, posinf=1e10, neginf=-1e10)
    if method == 'mean':
        imputer = SimpleImputer(strategy='mean')
        X = imputer.fit_transform(X)
    elif method == 'zero':
        X[np.isnan(X)] = 0.0
    return X.astype(np.float32)

def main():
    parser = argparse.ArgumentParser(description='数据集准备脚本（支持 NaN 清理 + SMOTE）')
    parser.add_argument('--use_nist_features', action='store_true', help='使用 NIST 特征')
    parser.add_argument('--use_bit_features', action='store_true', help='使用比特统计特征（../data/bit_features.npy）')
    parser.add_argument('--no_smote', action='store_true', help='禁用 SMOTE')
    parser.add_argument('--impute', choices=['zero', 'mean'], default='mean', help='NaN 填补策略')
    parser.add_argument('--input_features', type=str, default=None, help='自定义特征路径')
    parser.add_argument('--input_data', type=str, default='./data/hash_dataset.pkl', help='原始数据路径')
    args = parser.parse_args()

    # ================================
    # 1. 加载特征和标签
    # ================================
    if args.input_features:
        features_path = args.input_features
    elif args.use_bit_features:
        features_path = './data/bit_features.npy'  # 新特征路径
    elif args.use_nist_features:
        features_path = './data/features.npy'
    else:
        features_path = './data/features.npy'  # 默认

    print(f"加载特征矩阵: {features_path}")
    X = np.load(features_path)
    print(f"原始特征形状: {X.shape}")

    df = pd.read_pickle(args.input_data)
    y = LabelEncoder().fit_transform(df['algorithm'])
    print(f"标签数量: {len(y)}，类别: {np.unique(y)}")

    if X.shape[0] != len(y):
        raise ValueError(f"特征数量 {X.shape[0]} 与标签数量 {len(y)} 不匹配！")

    # ================================
    # 2. 清理 NaN / Inf
    # ================================
    print(f"清理 NaN/Inf（策略: {args.impute}）...")
    X_clean = clean_features(X, method=args.impute)
    nan_count = np.isnan(X_clean).sum()
    inf_count = np.isinf(X_clean).sum()
    print(f"清理后 NaN: {nan_count}, Inf: {inf_count}")

    # ================================
    # 3. 划分数据集
    # ================================
    X_train, X_temp, y_train, y_temp = train_test_split(
        X_clean, y, test_size=0.2, stratify=y, random_state=42
    )
    X_val, X_test, y_val, y_test = train_test_split(
        X_temp, y_temp, test_size=0.5, stratify=y_temp, random_state=42
    )

    # ================================
    # 4. 标准化
    # ================================
    print("标准化特征...")
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_val_scaled = scaler.transform(X_val)
    X_test_scaled = scaler.transform(X_test)

    if np.isnan(X_train_scaled).any():
        print("警告：标准化后仍有 NaN，强制填补...")
        X_train_scaled = np.nan_to_num(X_train_scaled, nan=0.0)
        X_val_scaled = np.nan_to_num(X_val_scaled, nan=0.0)
        X_test_scaled = np.nan_to_num(X_test_scaled, nan=0.0)

    # ================================
    # 5. SMOTE
    # ================================
    if not args.no_smote and SMOTE_AVAILABLE:
        print("执行 SMOTE...")
        try:
            smote = SMOTE(random_state=42)
            X_train_res, y_train_res = smote.fit_resample(X_train_scaled, y_train)
            print(f"SMOTE 后训练集大小: {X_train_res.shape[0]}")
        except Exception as e:
            print(f"SMOTE 失败: {e}，回退原始")
            X_train_res, y_train_res = X_train_scaled, y_train
    else:
        print("跳过 SMOTE")
        X_train_res, y_train_res = X_train_scaled, y_train

    # ================================
    # 6. 保存结果
    # ================================
    suffix = '' if args.use_bit_features else '' if args.use_nist_features else ''
    np.save(f'./data/X_train{suffix}.npy', X_train_res)
    np.save(f'./data/X_val{suffix}.npy', X_val_scaled)
    np.save(f'./data/X_test{suffix}.npy', X_test_scaled)
    np.save(f'./data/y_train{suffix}.npy', y_train_res)
    np.save(f'./data/y_val{suffix}.npy', y_val)
    np.save(f'./data/y_test{suffix}.npy', y_test)

    print(f"\n数据集准备完成！")
    print(f" 训练集: {X_train_res.shape[0]} 条")
    print(f" 验证集: {X_val_scaled.shape[0]} 条")
    print(f" 测试集: {X_test_scaled.shape[0]} 条")
    print(f" 特征维度: {X_train_res.shape[1]}")
    print(f" 保存路径: ../data/X_*{suffix}.npy")

if __name__ == "__main__":
    main()