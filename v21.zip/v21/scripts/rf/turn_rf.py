import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import RandomizedSearchCV
from sklearn.metrics import accuracy_score, classification_report
from joblib import dump
import argparse
import time
from scipy.stats import randint, uniform

# -------------------------
# 解析命令行参数
# -------------------------
parser = argparse.ArgumentParser(description='随机森林自动调参训练脚本')
parser.add_argument('--features', type=int, nargs='*',
                    help='使用的特征索引列表，如: 0 1 2 3 4')
parser.add_argument('--n_iter', type=int, default=50,
                    help='RandomizedSearchCV 迭代次数')
parser.add_argument('--cv', type=int, default=3,
                    help='交叉验证折数')
args = parser.parse_args()

# -------------------------
# 加载数据
# -------------------------
X_train = np.load('../../data/X_train.npy')
y_train = np.load('../../data/y_train.npy')
X_val = np.load('../../data/X_val.npy')
y_val = np.load('../../data/y_val.npy')

if args.features is not None:
    X_train = X_train[:, args.features]
    X_val = X_val[:, args.features]

print(f"训练集大小: {X_train.shape}")
print(f"验证集大小: {X_val.shape}")

# -------------------------
# 定义参数空间
# -------------------------
param_dist = {
    'n_estimators': randint(500, 2000),
    'max_depth': randint(10, 50),
    'min_samples_split': randint(2, 10),
    'min_samples_leaf': randint(1, 5),
    'max_features': ['sqrt', 'log2', 0.5, 0.7, 1.0],
    'class_weight': ['balanced', None],
    'bootstrap': [True, False]
}

# -------------------------
# 创建随机森林对象
# -------------------------
rf = RandomForestClassifier(random_state=42, n_jobs=-1)

# -------------------------
# 随机搜索
# -------------------------
print("开始随机搜索调参...")
start_time = time.time()

random_search = RandomizedSearchCV(
    rf,
    param_distributions=param_dist,
    n_iter=args.n_iter,
    scoring='accuracy',
    cv=args.cv,
    verbose=2,
    n_jobs=-1,
    random_state=42
)

random_search.fit(X_train, y_train)

end_time = time.time()
print(f"\n随机搜索完成，耗时: {end_time - start_time:.2f} 秒")
print(f"最佳参数组合: {random_search.best_params_}")
print(f"交叉验证最佳得分: {random_search.best_score_:.4f}")

# -------------------------
# 在验证集上评估
# -------------------------
best_rf = random_search.best_estimator_
y_pred = best_rf.predict(X_val)
val_acc = accuracy_score(y_val, y_pred)
print(f"验证集准确率: {val_acc:.4f}")
print("\n分类报告:")
print(classification_report(y_val, y_pred))

# -------------------------
# 保存模型
# -------------------------
dump(best_rf, '../../models/rf_model_tuned.joblib')
print("\n调参后的随机森林模型已保存到 '../../models/rf_model_tuned.joblib'")
