#!/usr/bin/env python3
import numpy as np
import xgboost as xgb
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, accuracy_score
import joblib

CACHE = "./cache_prefix64_markov"

X_val = np.load(f"{CACHE}/X_val.npy")
y_raw = np.load(f"{CACHE}/y_val.npy")

le = joblib.load("label_encoder.pkl")
y = le.transform(y_raw)

model = xgb.XGBClassifier()
model.load_model("xgb_prefix64_markov.ubj")

preds = model.predict(X_val)

print("Accuracy:", accuracy_score(y, preds))
print(classification_report(y, preds, target_names=le.classes_))
