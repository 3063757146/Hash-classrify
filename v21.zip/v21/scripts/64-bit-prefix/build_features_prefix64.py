#!/usr/bin/env python3
import numpy as np
import pickle
import os
from tqdm import tqdm

OUT_DIR = "./cache_prefix64_markov"
os.makedirs(OUT_DIR, exist_ok=True)

# =========================
# 工具函数
# =========================
def hex_to_bits(hex_str, n_bits=64):
    hex_len = n_bits // 4
    h = hex_str[:hex_len]
    b = bin(int(h, 16))[2:].zfill(n_bits)
    return np.fromiter((int(x) for x in b), dtype=np.float32)

def bin_to_bits(bin_str, n_bits=64):
    b = bin_str[:n_bits]
    return np.fromiter((int(x) for x in b), dtype=np.float32)

def markov_2bit(bits):
    states = []
    for i in range(0, len(bits) - 1, 2):
        states.append(int(bits[i]) * 2 + int(bits[i + 1]))

    mat = np.zeros((4, 4), dtype=np.float32)
    for i in range(len(states) - 1):
        mat[states[i], states[i + 1]] += 1

    mat /= (mat.sum() + 1e-8)
    return mat.flatten()

# =========================
# 主提取逻辑（DataFrame 版）
# =========================
def extract(pkl_path, split):
    with open(pkl_path, "rb") as f:
        df = pickle.load(f)

    X, y = [], []

    for _, row in tqdm(df.iterrows(), total=len(df), desc=f"Extract {split}"):
        label = row["algorithm"]

        if "digest_hex" in row and isinstance(row["digest_hex"], str):
            bits = hex_to_bits(row["digest_hex"], 64)
        elif "digest_bin" in row and isinstance(row["digest_bin"], str):
            bits = bin_to_bits(row["digest_bin"], 64)
        else:
            continue

        markov = markov_2bit(bits)
        feat = np.concatenate([bits, markov])

        X.append(feat)
        y.append(label)

    X = np.asarray(X, dtype=np.float32)
    y = np.asarray(y)

    np.save(f"{OUT_DIR}/X_{split}.npy", X)
    np.save(f"{OUT_DIR}/y_{split}.npy", y)

    print(f"[DONE] {split}: X={X.shape}, y={y.shape}")

# =========================
if __name__ == "__main__":
    extract("hash_dataset.pkl", "train")
    extract("validate.pkl", "val")
