#!/usr/bin/env python3
import numpy as np
import xgboost as xgb
from sklearn.preprocessing import LabelEncoder
import joblib

CACHE = "./cache_prefix64_markov"

X = np.load(f"{CACHE}/X_train.npy")
y_raw = np.load(f"{CACHE}/y_train.npy")

le = LabelEncoder()
y = le.fit_transform(y_raw)

joblib.dump(le, "label_encoder.pkl")
np.save("label_classes.npy", le.classes_)

model = xgb.XGBClassifier(
    n_estimators=500,
    max_depth=8,
    learning_rate=0.05,
    subsample=0.9,
    colsample_bytree=0.9,
    objective="multi:softmax",
    num_class=len(le.classes_),
    tree_method="hist",
    n_jobs=8
)

model.fit(X, y)
model.save_model("xgb_prefix64_markov.ubj")

print("[DONE] Model trained & saved")
