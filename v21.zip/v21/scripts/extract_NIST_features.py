# scripts/extract_NIST_features.py
import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from tqdm import tqdm
import argparse
import sys
import warnings

warnings.filterwarnings('ignore')
sys.path.append('randomness_testsuite')

# ================================
# 1. 尝试导入 NIST 测试模块
# ================================
try:
    from randomness_testsuite.FrequencyTest import FrequencyTest
    from randomness_testsuite.RunTest import RunTest
    from randomness_testsuite.Matrix import Matrix
    from randomness_testsuite.Spectral import SpectralTest
    from randomness_testsuite.TemplateMatching import TemplateMatching
    from randomness_testsuite.Universal import Universal
    from randomness_testsuite.Complexity import ComplexityTest
    from randomness_testsuite.Serial import Serial
    from randomness_testsuite.ApproximateEntropy import ApproximateEntropy
    from randomness_testsuite.CumulativeSum import CumulativeSums
    from randomness_testsuite.RandomExcursions import RandomExcursions
    RANDOMNESS_TESTS = True
    print("✅ 成功导入 randomness_testsuite，可用完整 NIST 测试")
except Exception:
    RANDOMNESS_TESTS = False
    print("⚠️ randomness_testsuite 导入失败，使用简化 NIST 特征")

# ================================
# 2. 辅助函数
# ================================
def ensure_bytes(digest):
    if isinstance(digest, str):
        if digest.startswith("b'") or digest.startswith('b"'):
            return eval(digest)
        return bytes.fromhex(digest)
    return digest

def bytes_to_binary(digest_bytes: bytes) -> str:
    return ''.join(f'{b:08b}' for b in digest_bytes)

# ================================
# 3. 精简 NIST 特征
# ================================
def extract_nist_compact(digest_bin: str):
    n = len(digest_bin)
    ones = digest_bin.count('1')
    freq_bias = float(abs(ones / n - 0.5))
    blocks = [digest_bin[i:i+8] for i in range(0, n, 8)]
    block_bias = float(abs(np.mean([b.count('1') for b in blocks]) / 8 - 0.5)) if blocks else 0.0
    runs = sum(1 for i in range(1, n) if digest_bin[i] != digest_bin[i-1]) + 1
    runs_dev = float(abs(runs - (2*ones*(n-ones)/n + 1)) / n)
    longest_run = float(max(map(len, digest_bin.split('0'))) / 32.0)
    # 安全返回标量
    spectral = float(Serial.serial_test(digest_bin)[0][0]) if RANDOMNESS_TESTS else 0.0
    apen = float(ApproximateEntropy.approximate_entropy_test(digest_bin, 2)[0]) if RANDOMNESS_TESTS else 0.0
    cum_forward = float(CumulativeSums.cumulative_sums_test(digest_bin, 0)[0]) if RANDOMNESS_TESTS else 0.0
    cum_backward = float(CumulativeSums.cumulative_sums_test(digest_bin, 1)[0]) if RANDOMNESS_TESTS else 0.0
    return np.array([freq_bias, block_bias, runs_dev, longest_run, spectral, apen, cum_forward, cum_backward], dtype=np.float32)

# ================================
# 4. 联合输入-摘要特征 + 密码学特异性
# ================================
def extract_features_for_row(row):
    digest_bytes = ensure_bytes(row['digest_bytes'])
    digest_bin = bytes_to_binary(digest_bytes)

    # --- NIST 8维 ---
    nist_feats = extract_nist_compact(digest_bin)

    # --- 输入联合特征 ---
    input_bytes = ensure_bytes(row.get('input_hex', b''))
    if not input_bytes:
        input_bytes = b'\x00' * 64
    input_len = len(input_bytes)
    len_bin = np.array([
        int(input_len <= 64),
        int(64 < input_len <= 256),
        int(256 < input_len <= 1024),
        int(input_len > 1024)
    ], dtype=np.float32)
    input_head = input_bytes[:64]
    digest_head = digest_bytes[:64]
    xor_sum = float(np.sum([a ^ b for a, b in zip(input_head, digest_head)]) / 512.0)
    # 互信息近似
    joint_hist = np.zeros((16,16), dtype=float)
    for i in range(min(len(input_head), len(digest_head))):
        a, b = input_head[i] >> 4, digest_head[i] >> 4
        joint_hist[a,b] += 1
    if joint_hist.sum() > 0:
        joint_hist /= joint_hist.sum()
    mi = float(np.sum(joint_hist * np.log2(joint_hist + 1e-12)) + 4.0)
    mode_map = {'random':0,'structured':1,'edge':2}
    mode_vec = np.zeros(3, dtype=np.float32)
    mode = row.get('input_mode','random')
    if mode in mode_map:
        mode_vec[mode_map[mode]] = 1.0

    combined = np.concatenate([nist_feats, len_bin, [xor_sum, mi], mode_vec])

    # --- 密码学 IV 特异性 ---
    IVs = {
        'sm3': bytes.fromhex('7380166f4914b2b9172442d7da8a0600')[:8],
        'sha256': bytes.fromhex('6a09e667bb67ae8536c6f57a510e527f')[:8],
        'sha3_256': bytes([0x01]*8),
        'blake2s': bytes.fromhex('0123456789abcdef')[:8],
        'blake3': bytes.fromhex('6ba16b94e9d28f9f')[:8]
    }
    crypto_feats = np.zeros(5, dtype=np.float32)
    for idx, iv in enumerate(IVs.values()):
        hd = sum(bin(a ^ b).count('1') for a,b in zip(digest_bytes[:8], iv)) / 64.0
        crypto_feats[idx] = float(hd)

    final_feats = np.concatenate([combined, crypto_feats])
    return final_feats.astype(np.float32)

# ================================
# 5. 主函数
# ================================
def main():
    parser = argparse.ArgumentParser(description='提取改进 NIST + 联合特征')
    parser.add_argument('--input', type=str, default='../data/hash_dataset.pkl', help='输入数据集路径')
    parser.add_argument('--output', type=str, default='../data/features.npy', help='输出特征矩阵路径')
    parser.add_argument('--n_jobs', type=int, default=-1, help='并行进程数')
    parser.add_argument('--sample', type=int, default=None, help='仅处理前 N 条数据')
    args = parser.parse_args()

    print("加载数据集...")
    df = pd.read_pickle(args.input)
    if args.sample:
        df = df.head(args.sample)
    print(f"样本数量: {len(df)}")

    results = Parallel(n_jobs=args.n_jobs)(
        delayed(extract_features_for_row)(row) for _, row in tqdm(df.iterrows(), total=len(df))
    )

    features_array = np.stack(results)
    np.save(args.output, features_array)
    print(f"特征提取完成！特征矩阵形状: {features_array.shape}")

if __name__ == "__main__":
    main()
