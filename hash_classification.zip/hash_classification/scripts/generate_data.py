# scripts/generate_data.py  (改进版)
import os, random, hashlib, time, json
from gmssl import sm3
import blake3
import pandas as pd
from tqdm import tqdm
from joblib import Parallel, delayed

ALGORITHMS = ['sm3', 'sha256', 'sha3_256', 'blake2s', 'blake3']
SAMPLES_PER_ALG = 10000               # 每算法 10 w 条
RANDOM_SEED = 42
random.seed(RANDOM_SEED)

# ---------- 1. 统一输入池：三种模式 ----------
def build_input_pool():
    pool = []
    # (1) 随机字节
    for _ in range(SAMPLES_PER_ALG // 3):
        pool.append(('random', os.urandom(random.randint(10, 2_650))))
    # (2) 结构化文本
    templates = [
        "A" * 1000,
        '{"key": "value"}' * 100,
        "Wikipedia is a free online encyclopedia, " * 80
    ]
    for tpl in templates:
        for _ in range(SAMPLES_PER_ALG // 9):
            pool.append(('structured', tpl.encode()))
    # (3) 边缘/特殊
    specials = [b'', b'\x00' * 1024, b'\x01' * 512, b'\xff' * 256]
    for sp in specials:
        pool.extend([('edge', sp)] * (SAMPLES_PER_ALG // 15))
    # 补满
    while len(pool) < SAMPLES_PER_ALG:
        pool.append(('random', os.urandom(random.randint(10, 2_650))))
    random.shuffle(pool)
    return pool[:SAMPLES_PER_ALG]

# ---------- 2. 哈希计算 ----------
def compute_hash(alg: str, data: bytes) -> str:
    if alg == 'sm3':
        return sm3.sm3_hash(list(data))          # gmssl 返回 hex str
    if alg == 'sha256':
        return hashlib.sha256(data).hexdigest()
    if alg == 'sha3_256':
        return hashlib.sha3_256(data).hexdigest()
    if alg == 'blake2s':
        return hashlib.blake2s(data).hexdigest()
    if alg == 'blake3':
        return blake3.blake3(data).digest().hex()

# ---------- 3. 单条处理 ----------
def worker(args):
    alg, (mode, inp) = args
    try:
        hex_digest = compute_hash(alg, inp)
        byte_digest = bytes.fromhex(hex_digest)
        bin_digest = ''.join(f'{b:08b}' for b in byte_digest)
        return {
            'algorithm': alg,
            'input_hex': inp.hex(),
            'input_len': len(inp),
            'input_mode': mode,
            'digest_hex': hex_digest,
            'digest_bytes': byte_digest,
            'digest_bin': bin_digest
        }
    except Exception as e:
        print('worker error:', e)
        return None

# ---------- 4. 主流程 ----------
def main():
    os.makedirs('./data', exist_ok=True)
    pool = build_input_pool()
    records = []
    for alg in ALGORITHMS:
        print(f'>>> 生成 {alg} 哈希 …')
        res = Parallel(n_jobs=-1, backend='loky')(
            delayed(worker)((alg, item)) for item in tqdm(pool, desc=alg)
        )
        records.extend([r for r in res if r])

    df = pd.DataFrame(records)
    # 保存完整版（含输入）
    df.to_pickle('./data/hash_dataset_ext.pkl')
    df.to_csv('./data/hash_dataset_ext.csv', index=False)

    # 再保存一份“最小”版（仅摘要，方便对外发布）
    min_cols = ['algorithm', 'digest_hex', 'digest_bytes', 'digest_bin']
    df_min = df[min_cols].copy()
    df_min['digest_bytes'] = df_min['digest_bytes'].apply(lambda x: x.hex())
    df_min.to_pickle('./data/validate.pkl')
    df_min.to_csv('./data/validate.csv', index=False)

    # print(f'完整数据：{len(df)} 条，已落盘。')
    # print('---- 纯摘要 baseline（256-维字节直方图 + 熵 + 0-run）----')
    # from sklearn.ensemble import RandomForestClassifier
    # from sklearn.metrics import accuracy_score, classification_report
    # from sklearn.model_selection import StratifiedKFold
    # import numpy as np

    # X = np.stack([
    #     np.bincount(np.frombuffer(bytes.fromhex(h), dtype=np.uint8), minlength=256)
    #     for h in df_min['digest_hex']
    # ])
    # # 再加两个简单统计
    # ent = lambda h: -np.sum(np.bincount(np.frombuffer(bytes.fromhex(h), dtype=np.uint8)) / 32 *
    #                         np.log2(np.bincount(np.frombuffer(bytes.fromhex(h), dtype=np.uint8)) / 32 + 1e-12))
    # zero_run = lambda h: max(map(len, ''.join(f'{b:08b}' for b in bytes.fromhex(h)).split('1')))
    # extra = np.array([[ent(h), zero_run(h)] for h in df_min['digest_hex']])
    # X = np.hstack([X, extra])
    # y = df_min['algorithm'].values
    # accs = []
    # for train, test in StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_SEED).split(X, y):
    #     clf = RandomForestClassifier(n_estimators=500, n_jobs=-1, random_state=RANDOM_SEED)
    #     clf.fit(X[train], y[train])
    #     accs.append(accuracy_score(y[test], clf.predict(X[test])))
    # print('5 折 CV 准确率：', np.round(accs, 3), '均值：', np.mean(accs))
    # if np.mean(accs) <= 0.25:
    #     print('↑ 天花板过低，请继续走“输入-摘要联合特征”路线！')

if __name__ == '__main__':
    main()