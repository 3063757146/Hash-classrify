# scripts/xgb/train.py
try:
    from xgboost import XGBClassifier
    XGB_AVAILABLE = True
except ImportError:
    print("未安装XGBoost库")
    XGB_AVAILABLE = False
from sklearn.metrics import accuracy_score
from joblib import dump
import numpy as np
import time
import argparse

# 解析命令行参数
parser = argparse.ArgumentParser(description='XGBoost模型训练脚本')
parser.add_argument('--features', type=int, nargs='*',
                    help='使用的特征索引列表，如: 0 1 2 3 4')
parser.add_argument('--gpu',default='gpu', action='store_true',
                    help='是否使用GPU加速训练（需要CUDA支持）')
parser.add_argument('--n_estimators', type=int, default=500,
                    help='树的数量')
parser.add_argument('--learning_rate', type=float, default=0.1,
                    help='学习率')
parser.add_argument('--max_depth', type=int, default=8,
                    help='树的最大深度')
parser.add_argument('--subsample', type=float, default=0.8,
                    help='样本采样比例')
parser.add_argument('--colsample_bytree', type=float, default=0.8,
                    help='特征采样比例')
parser.add_argument('--reg_alpha', type=float, default=0.1,
                    help='L1正则化项')
parser.add_argument('--reg_lambda', type=float, default=1.0,
                    help='L2正则化项')
args = parser.parse_args()

if not XGB_AVAILABLE:
    print("XGBoost不可用，退出训练")
    exit(1)

X_train = np.load('../../data/X_train.npy')
y_train = np.load('../../data/y_train.npy')
X_val = np.load('../../data/X_val.npy')
y_val = np.load('../../data/y_val.npy')

print("开始XGBoost模型训练...")
print(f"训练集大小: {X_train.shape}")
print(f"验证集大小: {X_val.shape}")

# 处理特征选择
if args.features is not None:
    print(f"使用特征索引: {args.features}")
    X_train_xgb = X_train[:, args.features]
    X_val_xgb = X_val[:, args.features]
else:
    X_train_xgb = X_train
    X_val_xgb = X_val

# 训练XGBoost
print(f"\n训练XGBoost模型...")
# 根据参数决定是否使用GPU
device = 'cuda' if args.gpu else 'cpu'
try:
    print(f"配置: n_estimators={args.n_estimators}, learning_rate={args.learning_rate}, max_depth={args.max_depth}")
    print(f"       subsample={args.subsample}, colsample_bytree={args.colsample_bytree}")
    print(f"       reg_alpha={args.reg_alpha}, reg_lambda={args.reg_lambda}, device={device}")
    start_time = time.time()
    xgb = XGBClassifier(
        n_estimators=1000,
        max_depth=14,
        learning_rate=0.05,
        subsample=0.9,
        colsample_bytree=0.9,
        reg_alpha=0.1,
        reg_lambda=1.0,
        random_state=42,
        tree_method='hist', # 对CPU/GPU都高效
        device=device
    )
except Exception as e:
    print(f"设备{device}训练失败: {e}")
    if args.gpu:
        print("回退到CPU训练...")
        device = 'cpu'
        print(f"配置: n_estimators={args.n_estimators}, learning_rate={args.learning_rate}, max_depth={args.max_depth}")
        print(f"       subsample={args.subsample}, colsample_bytree={args.colsample_bytree}")
        print(f"       reg_alpha={args.reg_alpha}, reg_lambda={args.reg_lambda}, device={device}")
        start_time = time.time()
        xgb = XGBClassifier(
            n_estimators=args.n_estimators, 
            learning_rate=args.learning_rate, 
            max_depth=args.max_depth,
            subsample=args.subsample,
            colsample_bytree=args.colsample_bytree,
            reg_alpha=args.reg_alpha,
            reg_lambda=args.reg_lambda,
            random_state=42,
            device=device
        )
    else:
        raise e

# XGBoost自带进度显示
xgb.fit(X_train_xgb, y_train, eval_set=[(X_val_xgb, y_val)], verbose=50)

val_acc = accuracy_score(y_val, xgb.predict(X_val_xgb))
end_time = time.time()
print(f"XGBoost验证准确率: {val_acc:.4f}")
print(f"XGBoost训练耗时: {end_time - start_time:.2f} 秒")
dump(xgb, '../../models/xgb_model.joblib')

print("\nXGBoost模型训练完成！")