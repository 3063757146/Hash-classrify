# scripts/rf/train.py
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from joblib import dump
import numpy as np
import time
import argparse

# 解析命令行参数
parser = argparse.ArgumentParser(description='随机森林模型训练脚本')
parser.add_argument('--features', type=int, nargs='*',
                    help='使用的特征索引列表，如: 0 1 2 3 4')
parser.add_argument('--n_estimators', type=int, default=689,
                    help='树的数量')
parser.add_argument('--max_depth', type=int, default=37,
                    help='树的最大深度')
args = parser.parse_args()

X_train = np.load('../../data/X_train.npy')
y_train = np.load('../../data/y_train.npy')
X_val = np.load('../../data/X_val.npy')
y_val = np.load('../../data/y_val.npy')

print("开始随机森林模型训练...")
print(f"训练集大小: {X_train.shape}")
print(f"验证集大小: {X_val.shape}")

# 处理特征选择
if args.features is not None:
    print(f"使用特征索引: {args.features}")
    X_train_rf = X_train[:, args.features]
    X_val_rf = X_val[:, args.features]
else:
    X_train_rf = X_train
    X_val_rf = X_val

# 训练随机森林
print(f"\n训练随机森林模型...")
print(f"配置: n_estimators={args.n_estimators}, max_depth={args.max_depth}")
start_time = time.time()
rf = RandomForestClassifier(n_estimators=689,random_state=42, n_jobs=-1,bootstrap=True,  max_depth=37, max_features=0.7, min_samples_leaf=4, min_samples_split=8)
rf.fit(X_train_rf, y_train)
val_acc = accuracy_score(y_val, rf.predict(X_val_rf))
end_time = time.time()
print(f"随机森林验证准确率: {val_acc:.4f}")
print(f"随机森林训练耗时: {end_time - start_time:.2f} 秒")
dump(rf, '../../models/rf_model.joblib')

print("\n随机森林模型训练完成！")