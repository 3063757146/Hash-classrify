# scripts/setup.py
import sys
import subprocess
import os

def install_packages():
    packages = [
        'numpy', 'scipy', 'scikit-learn', 'joblib',
        'matplotlib', 'seaborn', 'pandas',
        'gmssl', 'blake3', 'pywavelets', 'tqdm'
    ]
    for pkg in packages:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', pkg])

def setup_nist_tests():
    try:
        import git
        if not os.path.exists('randomness_testsuite'):
            print("正在克隆randomness_testsuite...")
            git.cmd.Git().clone('https://github.com/stevenang/randomness_testsuite.git')
        else:
            print("randomness_testsuite已存在")
    except ImportError:
        print("未安装gitpython，将跳过randomness_testsuite克隆")
        # 手动创建目录
        if not os.path.exists('randomness_testsuite'):
            os.makedirs('randomness_testsuite')
    sys.path.append('randomness_testsuite')

if __name__ == '__main__':
    install_packages()
    setup_nist_tests()
    print("环境配置完成！")