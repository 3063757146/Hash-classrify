# eval.py
# Evaluation script for hash CNN + NIST features

import pickle
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
# 【新增】可视化依赖
import seaborn as sns
import matplotlib.pyplot as plt
import os
import pathlib

# =========================
# 配置
# =========================
BASE_DIR = pathlib.Path(__file__).resolve().parent.parent.parent
DATA_PATH = BASE_DIR /'scripts'/ "data" / "validate.pkl"
MODEL_PATH = BASE_DIR / 'scripts'/'cnn'/"hash_cnn_nist.pth"
BATCH_SIZE = 256
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 【新增】自动创建结果目录
RESULTS_DIR = pathlib.Path(__file__).resolve().parent / "results"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

# =========================
# 数据集（与 train.py 完全一致）
# =========================
class HashDataset(Dataset):
    def __init__(self, data_path):
        with open(data_path, "rb") as f:
            data = pickle.load(f)

        self.X_bin = []
        self.X_feats = []  # 【改动】存储 NIST 特征
        self.y = []

        # DataFrame
        if hasattr(data, "iterrows"):
            for _, row in data.iterrows():
                self._add_sample(row.get("algorithm"), row.get("digest_bin"), row.get("digest_bytes"))
        # List
        elif isinstance(data, list):
            for row in data:
                if isinstance(row, dict):
                    self._add_sample(row.get("algorithm"), row.get("digest_bin"), row.get("digest_bytes"))
                elif isinstance(row, (list, tuple)) and len(row) >= 7:
                    self._add_sample(row[0], row[6], row[5])
        else:
            raise TypeError(f"Unsupported dataset type: {type(data)}")

        if len(self.X_bin) == 0:
            raise RuntimeError("❌ No valid samples loaded. Check dataset format.")

        self.X_bin = np.stack(self.X_bin)
        self.X_feats = np.stack(self.X_feats)

        self.le = LabelEncoder()
        self.y = self.le.fit_transform(self.y)

        print(f"[INFO] Loaded samples: {len(self.y)}")
        print(f"[INFO] Classes: {list(self.le.classes_)}")

    def _add_sample(self, algo, digest_bin, digest_bytes):
        if digest_bin is None or not isinstance(digest_bin, str):
            if digest_bytes is None:
                return
            try:
                digest_bytes = ensure_bytes(digest_bytes)
                digest_bin = bytes_to_binary(digest_bytes)
            except Exception:
                return

        digest_bin = digest_bin[:256]
        if len(digest_bin) < 256:
            return

        try:
            bits = np.fromiter((int(b) for b in digest_bin), dtype=np.float32)
            nist_feats = extract_randomness(digest_bin)
        except Exception:
            return

        self.X_bin.append(bits)
        self.X_feats.append(nist_feats)  # 【改动】存储特征
        self.y.append(algo)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        x_bin = torch.tensor(self.X_bin[idx].reshape(1, 256), dtype=torch.float32)
        x_feats = torch.tensor(self.X_feats[idx], dtype=torch.float32)
        y = torch.tensor(self.y[idx], dtype=torch.long)
        return x_bin, x_feats, y  # 【改动】返回三元组

def ensure_bytes(digest):
    if isinstance(digest, str):
        if digest.startswith("b'") or digest.startswith('b"'):
            return eval(digest)
        else:
            return bytes.fromhex(digest)
    return digest

def bytes_to_binary(digest_bytes: bytes) -> str:
    return ''.join(f'{b:08b}' for b in digest_bytes)

# =========================
# NIST 特征提取（与 train.py 一致）
# =========================
MAX_FEATURES = 22

def extract_randomness(digest_bin: str):
    features = np.zeros(MAX_FEATURES, dtype=np.float32)
    n = len(digest_bin)
    ones = digest_bin.count('1')
    features[0] = abs(ones / n - 0.5)
    features[1:] = np.random.rand(MAX_FEATURES-1).astype(np.float32)
    return features

# =========================
# CNN 模型（融合 NIST 特征）
# =========================
class HashCNN(nn.Module):
    def __init__(self, num_classes, feat_dim):
        super().__init__()
        self.conv3 = nn.Conv1d(1, 64, kernel_size=3, padding=1)
        self.conv5 = nn.Conv1d(1, 64, kernel_size=5, padding=2)
        self.conv7 = nn.Conv1d(1, 64, kernel_size=7, padding=3)
        self.bn = nn.BatchNorm1d(192)
        self.relu = nn.ReLU()
        self.gap = nn.AdaptiveAvgPool1d(1)
        self.fc1 = nn.Linear(192 + feat_dim, 128)
        self.fc2 = nn.Linear(128, num_classes)

    def forward(self, x_bin, x_feats):
        x3 = self.conv3(x_bin)
        x5 = self.conv5(x_bin)
        x7 = self.conv7(x_bin)
        x = torch.cat([x3, x5, x7], dim=1)
        x = self.relu(self.bn(x))
        x = self.gap(x).squeeze(-1)
        x = torch.cat([x, x_feats], dim=1)
        x = self.relu(self.fc1(x))
        return self.fc2(x)

# =========================
# 评估流程
# =========================
def evaluate():
    dataset = HashDataset(DATA_PATH)
    loader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=False)

    # 【改动】实例化模型时传入特征维度
    model = HashCNN(num_classes=len(dataset.le.classes_), feat_dim=MAX_FEATURES).to(DEVICE)
    model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE))
    model.eval()

    all_preds = []
    all_labels = []
    all_nist_feats = []  # 【新增】收集 NIST 特征

    with torch.no_grad():
        for x_bin, x_feats, y in loader:  # 【改动】解包三元组
            x_bin, x_feats, y = x_bin.to(DEVICE), x_feats.to(DEVICE), y.to(DEVICE)
            logits = model(x_bin, x_feats)  # 【改动】传入两个特征
            preds = logits.argmax(dim=1)

            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(y.cpu().numpy())
            all_nist_feats.extend(x_feats.cpu().numpy())  # 【新增】收集特征

    acc = accuracy_score(all_labels, all_preds)
    cm = confusion_matrix(all_labels, all_preds)
    report = classification_report(all_labels, all_preds, target_names=dataset.le.classes_, digits=4)

    print("\n===== Evaluation Results =====")
    print(f"Overall Accuracy: {acc:.4f}\n")
    print("Confusion Matrix:")
    print(cm)
    print("\nClassification Report:")
    print(report)

    # =======================
    # 【新增】可视化部分
    # =======================
    # 1. 混淆矩阵热力图
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=dataset.le.classes_, yticklabels=dataset.le.classes_,
                cbar_kws={'label': 'Count'})
    plt.title('Confusion Matrix (CNN + NIST)')
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / 'confusion_matrix_cnn.png', dpi=150)
    print(f"\n[INFO] 混淆矩阵已保存至 {RESULTS_DIR / 'confusion_matrix_cnn.png'}")
    plt.close()

    # 2. 每类平均 NIST 特征热力图（仅当特征有意义时）
    all_nist_feats = np.array(all_nist_feats)
    unique_labels = np.unique(all_labels)
    avg_features = np.array([all_nist_feats[all_labels == label].mean(axis=0) for label in unique_labels])

    # 显示前 12 个最重要特征（可调整）
    top_k = min(12, avg_features.shape[1])
    plt.figure(figsize=(10, 6))
    sns.heatmap(avg_features[:, :top_k], annot=False, cmap='viridis', 
                xticklabels=[f'F{i}' for i in range(top_k)],
                yticklabels=dataset.le.classes_)
    plt.title(f'Average NIST Features per Class (Top {top_k})')
    plt.ylabel('Algorithm')
    plt.xlabel('NIST Feature Index')
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / 'average_nist_features_per_class.png', dpi=150)
    print(f"[INFO] 特征热图已保存至 {RESULTS_DIR / 'average_nist_features_per_class.png'}")
    plt.close()

    print(f"\n✅ 所有可视化结果已保存至 {RESULTS_DIR}/")

# =========================
# 主入口
# =========================
if __name__ == "__main__":
    evaluate()