# train.py
# Hash Algorithm Classification using CNN (digest_bin)

import pickle
import numpy as np
import torch
import os
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, random_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score

# =========================
# 配置
# =========================
DATA_PATH = "./hash_dataset.pkl"
BATCH_SIZE = 128
EPOCHS = 25
LEARNING_RATE = 1e-3
VAL_SPLIT = 0.2
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"[INFO] Using device: {DEVICE}")


RESUME        = 1
EXTRA_EPOCHS  = 15   # 想再训多少 epoch
CKPT_PATH     = "hash_cnn_bin.pth"   # 旧权重


# =========================
# 数据集
# =========================
class HashDataset(Dataset):
    def __init__(self, data_path):
        with open(data_path, "rb") as f:
            data = pickle.load(f)

        self.X = []
        self.y = []

        # ---------- DataFrame ----------
        if hasattr(data, "iterrows"):
            for _, row in data.iterrows():
                self._add_sample(
                    row.get("algorithm"),
                    row.get("digest_bin")
                )

        # ---------- list ----------
        elif isinstance(data, list):
            for row in data:
                # list[dict]
                if isinstance(row, dict):
                    self._add_sample(
                        row.get("algorithm"),
                        row.get("digest_bin")
                    )
                # list[list] or tuple
                elif isinstance(row, (list, tuple)) and len(row) >= 4:
                    self._add_sample(row[0], row[3])

        else:
            raise TypeError(f"Unsupported dataset type: {type(data)}")

        if len(self.X) == 0:
            raise RuntimeError("❌ No valid samples loaded. Check dataset format.")

        self.X = np.stack(self.X)
        self.le = LabelEncoder()
        self.y = self.le.fit_transform(self.y)

        print(f"[INFO] Loaded samples: {len(self.y)}")
        print(f"[INFO] Classes: {list(self.le.classes_)}")

    def _add_sample(self, algo, digest_bin):
        if not isinstance(digest_bin, str) or len(digest_bin) != 256:
            return
        try:
            bits = np.fromiter((int(b) for b in digest_bin), dtype=np.float32)
        except Exception:
            return
        self.X.append(bits)
        self.y.append(algo)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        x = self.X[idx].reshape(1, 256)  # (C=1, L=256)
        y = self.y[idx]
        return torch.tensor(x), torch.tensor(y)

# =========================
# CNN 模型（论文级）
# =========================
class HashCNN(nn.Module):
    def __init__(self, num_classes):
        super().__init__()

        self.conv3 = nn.Conv1d(1, 64, kernel_size=3, padding=1)
        self.conv5 = nn.Conv1d(1, 64, kernel_size=5, padding=2)
        self.conv7 = nn.Conv1d(1, 64, kernel_size=7, padding=3)

        self.bn = nn.BatchNorm1d(192)
        self.relu = nn.ReLU()

        # Global Average Pooling
        self.gap = nn.AdaptiveAvgPool1d(1)

        self.fc = nn.Linear(192, num_classes)

    def forward(self, x):
        x3 = self.conv3(x)
        x5 = self.conv5(x)
        x7 = self.conv7(x)

        x = torch.cat([x3, x5, x7], dim=1)
        x = self.relu(self.bn(x))
        x = self.gap(x).squeeze(-1)
        return self.fc(x)

# =========================
# 训练流程
# =========================
def train():
    dataset = HashDataset(DATA_PATH)

    val_size = int(len(dataset) * VAL_SPLIT)
    train_size = len(dataset) - val_size
    train_set, val_set = random_split(dataset, [train_size, val_size])

    train_loader = DataLoader(train_set, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_set, batch_size=BATCH_SIZE)

    model = HashCNN(num_classes=len(np.unique(dataset.y))).to(DEVICE)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)

    for epoch in range(EPOCHS):
        model.train()
        train_preds, train_labels = [], []

        for x, y in train_loader:
            x, y = x.to(DEVICE), y.to(DEVICE)

            optimizer.zero_grad()
            logits = model(x)
            loss = criterion(logits, y)
            loss.backward()
            optimizer.step()

            train_preds.extend(logits.argmax(1).cpu().numpy())
            train_labels.extend(y.cpu().numpy())

        train_acc = accuracy_score(train_labels, train_preds)

        model.eval()
        val_preds, val_labels = [], []
        with torch.no_grad():
            for x, y in val_loader:
                x, y = x.to(DEVICE), y.to(DEVICE)
                logits = model(x)
                val_preds.extend(logits.argmax(1).cpu().numpy())
                val_labels.extend(y.cpu().numpy())

        val_acc = accuracy_score(val_labels, val_preds)

        print(
            f"Epoch [{epoch+1:02d}/{EPOCHS}] "
            f"Train Acc: {train_acc:.4f} | Val Acc: {val_acc:.4f}"
        )

    torch.save(model.state_dict(), "hash_cnn_bin.pth")
    print("[INFO] Model saved to hash_cnn_bin.pth")

# ==========================================================
# 【新增】复训函数
# ==========================================================
def resume_train():
    if not os.path.isfile(CKPT_PATH):
        raise FileNotFoundError(f"{CKPT_PATH} 不存在，无法复训！")
    dataset = HashDataset(DATA_PATH)
    val_size  = int(len(dataset) * VAL_SPLIT)
    train_size= len(dataset) - val_size
    train_set, val_set = random_split(dataset, [train_size, val_size])

    train_loader = DataLoader(train_set, batch_size=BATCH_SIZE, shuffle=True)
    val_loader   = DataLoader(val_set,   batch_size=BATCH_SIZE)

    model = HashCNN(num_classes=len(np.unique(dataset.y))).to(DEVICE)
    model.load_state_dict(torch.load(CKPT_PATH, map_location=DEVICE))
    print(f"[INFO] 已加载 checkpoint：{CKPT_PATH}")

    criterion = nn.CrossEntropyLoss()
    # 学习率可酌情调小
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE*0.5)

    for epoch in range(EXTRA_EPOCHS):
        model.train()
        train_preds, train_labels = [], []
        for x, y in train_loader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            optimizer.zero_grad()
            logits = model(x)
            loss = criterion(logits, y)
            loss.backward()
            optimizer.step()
            train_preds.extend(logits.argmax(1).cpu().numpy())
            train_labels.extend(y.cpu().numpy())
        train_acc = accuracy_score(train_labels, train_preds)

        model.eval()
        val_preds, val_labels = [], []
        with torch.no_grad():
            for x, y in val_loader:
                x, y = x.to(DEVICE), y.to(DEVICE)
                logits = model(x)
                val_preds.extend(logits.argmax(1).cpu().numpy())
                val_labels.extend(y.cpu().numpy())
        val_acc = accuracy_score(val_labels, val_preds)

        print(f"Resume Epoch [{epoch+1:02d}/{EXTRA_EPOCHS}] "
              f"Train Acc: {train_acc:.4f} | Val Acc: {val_acc:.4f}")

    new_ckpt = f"hash_cnn_bin_resume_{EXTRA_EPOCHS}.pth"
    torch.save(model.state_dict(), new_ckpt)
    print(f"[INFO] 复训完成，新权重已保存为 {new_ckpt}")

# =========================
# 【改动】主入口
# =========================
if __name__ == "__main__":
    if RESUME:
        resume_train()
    else:
        train()