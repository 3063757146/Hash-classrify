from torch.utils.data import random_split
from dataset import HashBitDataset

dataset = HashBitDataset('./data/hash_dataset_min.csv')

N = len(dataset)
train_size = int(0.8 * N)
test_size = N - train_size

train_set, test_set = random_split(
    dataset, [train_size, test_size]
)

print('Train:', len(train_set), 'Test:', len(test_set))
