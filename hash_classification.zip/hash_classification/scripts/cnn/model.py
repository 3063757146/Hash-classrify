import torch
import torch.nn as nn
import torch.nn.functional as F

class FinalHashCNN(nn.Module):
    def __init__(self, num_classes=5):
        super().__init__()

        # ---- view 1: bit-level ----
        self.bit_embed = nn.Embedding(2, 8)
        self.bit_cnn = nn.Sequential(
            nn.Conv1d(8, 64, 3, padding=1),
            nn.ReLU(),
            nn.Conv1d(64, 128, 5, padding=2),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1)
        )

        # ---- view 2: byte-level ----
        self.byte_embed = nn.Embedding(256, 16)
        self.byte_cnn = nn.Sequential(
            nn.Conv1d(16, 64, 3, padding=1),
            nn.ReLU(),
            nn.Conv1d(64, 128, 3, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1)
        )

        # ---- fusion ----
        self.fc = nn.Sequential(
            nn.Linear(256, 256),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(256, num_classes)
        )

    def forward(self, bits, bytes_):
        # bits: (B, 256)
        b = self.bit_embed(bits).permute(0, 2, 1)
        b = self.bit_cnn(b).squeeze(-1)

        # bytes_: (B, 32)
        y = self.byte_embed(bytes_).permute(0, 2, 1)
        y = self.byte_cnn(y).squeeze(-1)

        z = torch.cat([b, y], dim=1)
        return self.fc(z)
