import torch
from torch.utils.data import Dataset
import pandas as pd

LABEL_MAP = {
    'sm3': 0,
    'sha256': 1,
    'sha3_256': 2,
    'blake2s': 3,
    'blake3': 4
}

class HashBitDataset(Dataset):
    def __init__(self, csv_path):
        df = pd.read_csv(csv_path)

        self.X = torch.tensor(
            df['digest_bin'].apply(lambda s: list(map(int, s))).tolist(),
            dtype=torch.long
        )
        self.y = torch.tensor(
            [LABEL_MAP[a] for a in df['algorithm']],
            dtype=torch.long
        )

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        bits = torch.tensor(list(map(int, self.bin[idx])), dtype=torch.long)
        bytes_ = torch.tensor(bytes.fromhex(self.hex[idx]), dtype=torch.long)
        return bits, bytes_, self.y[idx]
