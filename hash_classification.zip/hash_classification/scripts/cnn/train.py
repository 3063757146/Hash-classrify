# train.py
# Hash Algorithm Classification using CNN + NIST features
import os
import pickle
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, random_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score

# =========================
# 配置
# =========================
DATA_PATH = "./hash_dataset.pkl"
BATCH_SIZE = 128
EPOCHS = 50
LEARNING_RATE = 1e-3
VAL_SPLIT = 0.2
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:",DEVICE)
# =========================
# NIST 特征提取 (简化为 22 维)
# =========================
MAX_FEATURES = 22

# 【新增】复训开关  1=继续训  0=从头训
RESUME = 1
EXTRA_EPOCHS = 20   # 想再训多少 epoch
CKPT_PATH = "hash_cnn_nist.pth"   # 旧权重路径

def extract_randomness(digest_bin: str):
    """
    返回 22 维简化特征：
    0: Monobit 频率
    1: Block frequency
    2: Runs deviation
    3: Longest run / 32
    4: Binary matrix rank
    5: Spectral
    6: Approximate Entropy
    7: Cumulative sum forward
    8: Cumulative sum backward
    9-21: Random Excursions 各状态统计 (12 维)
    """
    features = np.zeros(MAX_FEATURES, dtype=np.float32)
    n = len(digest_bin)
    ones = digest_bin.count('1')
    features[0] = abs(ones / n - 0.5)

    # 其他特征 placeholder (如果 NIST 输出有问题可先用随机数)
    features[1:] = np.random.rand(MAX_FEATURES-1).astype(np.float32)
    return features

def bytes_to_binary(digest_bytes: bytes) -> str:
    return ''.join(f'{b:08b}' for b in digest_bytes)

def ensure_bytes(digest):
    if isinstance(digest, str):
        if digest.startswith("b'") or digest.startswith('b"'):
            return eval(digest)
        else:
            return bytes.fromhex(digest)
    return digest

# =========================
# 数据集
# =========================
class HashDataset(Dataset):
    def __init__(self, data_path):
        with open(data_path, "rb") as f:
            data = pickle.load(f)

        self.X_bin = []
        self.X_feats = []
        self.y = []

        # DataFrame
        if hasattr(data, "iterrows"):
            for _, row in data.iterrows():
                self._add_sample(row.get("algorithm"), row.get("digest_bin"), row.get("digest_bytes"))
        # List
        elif isinstance(data, list):
            for row in data:
                if isinstance(row, dict):
                    self._add_sample(row.get("algorithm"), row.get("digest_bin"), row.get("digest_bytes"))
                elif isinstance(row, (list, tuple)) and len(row) >= 7:
                    self._add_sample(row[0], row[6], row[5])
        else:
            raise TypeError(f"Unsupported dataset type: {type(data)}")

        if len(self.X_bin) == 0:
            raise RuntimeError("❌ No valid samples loaded. Check dataset format.")

        self.X_bin = np.stack(self.X_bin)
        self.X_feats = np.stack(self.X_feats)

        self.le = LabelEncoder()
        self.y = self.le.fit_transform(self.y)

        print(f"[INFO] Loaded samples: {len(self.y)}")
        print(f"[INFO] Classes: {list(self.le.classes_)}")

    def _add_sample(self, algo, digest_bin, digest_bytes):
        if digest_bin is None or not isinstance(digest_bin, str):
            if digest_bytes is None:
                return
            try:
                digest_bytes = ensure_bytes(digest_bytes)
                digest_bin = bytes_to_binary(digest_bytes)
            except Exception:
                return

        digest_bin = digest_bin[:256]
        if len(digest_bin) < 256:
            return

        try:
            bits = np.fromiter((int(b) for b in digest_bin), dtype=np.float32)
            nist_feats = extract_randomness(digest_bin)
        except Exception:
            return

        self.X_bin.append(bits)
        self.X_feats.append(nist_feats)
        self.y.append(algo)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        x_bin = torch.tensor(self.X_bin[idx].reshape(1, 256), dtype=torch.float32)
        x_feats = torch.tensor(self.X_feats[idx], dtype=torch.float32)
        y = torch.tensor(self.y[idx], dtype=torch.long)
        return x_bin, x_feats, y

# =========================
# CNN + 特征融合模型
# =========================
class HashCNN(nn.Module):
    def __init__(self, num_classes, feat_dim):
        super().__init__()
        self.conv3 = nn.Conv1d(1, 64, kernel_size=3, padding=1)
        self.conv5 = nn.Conv1d(1, 64, kernel_size=5, padding=2)
        self.conv7 = nn.Conv1d(1, 64, kernel_size=7, padding=3)
        self.bn = nn.BatchNorm1d(192)
        self.relu = nn.ReLU()
        self.gap = nn.AdaptiveAvgPool1d(1)
        self.fc1 = nn.Linear(192 + feat_dim, 128)
        self.fc2 = nn.Linear(128, num_classes)

    def forward(self, x_bin, x_feats):
        x3 = self.conv3(x_bin)
        x5 = self.conv5(x_bin)
        x7 = self.conv7(x_bin)
        x = torch.cat([x3, x5, x7], dim=1)
        x = self.relu(self.bn(x))
        x = self.gap(x).squeeze(-1)
        x = torch.cat([x, x_feats], dim=1)
        x = self.relu(self.fc1(x))
        return self.fc2(x)

# =========================
# 训练流程
# =========================
def train():
    dataset = HashDataset(DATA_PATH)
    val_size = int(len(dataset) * VAL_SPLIT)
    train_size = len(dataset) - val_size
    train_set, val_set = random_split(dataset, [train_size, val_size])

    train_loader = DataLoader(train_set, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_set, batch_size=BATCH_SIZE)

    model = HashCNN(num_classes=len(np.unique(dataset.y)), feat_dim=MAX_FEATURES).to(DEVICE)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)

    for epoch in range(EPOCHS):
        model.train()
        train_preds, train_labels = [], []

        for x_bin, x_feats, y in train_loader:
            x_bin, x_feats, y = x_bin.to(DEVICE), x_feats.to(DEVICE), y.to(DEVICE)
            optimizer.zero_grad()
            logits = model(x_bin, x_feats)
            loss = criterion(logits, y)
            loss.backward()
            optimizer.step()

            train_preds.extend(logits.argmax(1).cpu().numpy())
            train_labels.extend(y.cpu().numpy())

        train_acc = accuracy_score(train_labels, train_preds)

        model.eval()
        val_preds, val_labels = [], []
        with torch.no_grad():
            for x_bin, x_feats, y in val_loader:
                x_bin, x_feats, y = x_bin.to(DEVICE), x_feats.to(DEVICE), y.to(DEVICE)
                logits = model(x_bin, x_feats)
                val_preds.extend(logits.argmax(1).cpu().numpy())
                val_labels.extend(y.cpu().numpy())

        val_acc = accuracy_score(val_labels, val_preds)
        print(f"Epoch [{epoch+1:02d}/{EPOCHS}] Train Acc: {train_acc:.4f} | Val Acc: {val_acc:.4f}")

    torch.save(model.state_dict(), "hash_cnn_nist.pth")
    print("[INFO] Model saved to hash_cnn_nist.pth")

# ==========================================================
# 【新增】复训函数
# ==========================================================
def resume_train():
    if not os.path.isfile(CKPT_PATH):
        raise FileNotFoundError(f"{CKPT_PATH} 不存在，无法复训！")
    
    dataset = HashDataset(DATA_PATH)
    val_size  = int(len(dataset) * VAL_SPLIT)
    train_size= len(dataset) - val_size
    train_set, val_set = random_split(dataset, [train_size, val_size])

    train_loader = DataLoader(train_set, batch_size=BATCH_SIZE, shuffle=True)
    val_loader   = DataLoader(val_set,   batch_size=BATCH_SIZE)

    model = HashCNN(num_classes=len(np.unique(dataset.y)), feat_dim=MAX_FEATURES).to(DEVICE)
    model.load_state_dict(torch.load(CKPT_PATH, map_location=DEVICE))
    print(f"[INFO] 已加载 checkpoint：{CKPT_PATH}")

    criterion = nn.CrossEntropyLoss()
    # 学习率可酌情调小
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE*0.5)

    for epoch in range(EXTRA_EPOCHS):
        model.train()
        train_preds, train_labels = [], []
        for x_bin, x_feats, y in train_loader:
            x_bin, x_feats, y = x_bin.to(DEVICE), x_feats.to(DEVICE), y.to(DEVICE)
            optimizer.zero_grad()
            logits = model(x_bin, x_feats)
            loss = criterion(logits, y)
            loss.backward()
            optimizer.step()
            train_preds.extend(logits.argmax(1).cpu().numpy())
            train_labels.extend(y.cpu().numpy())
        train_acc = accuracy_score(train_labels, train_preds)

        model.eval()
        val_preds, val_labels = [], []
        with torch.no_grad():
            for x_bin, x_feats, y in val_loader:
                x_bin, x_feats, y = x_bin.to(DEVICE), x_feats.to(DEVICE), y.to(DEVICE)
                logits = model(x_bin, x_feats)
                val_preds.extend(logits.argmax(1).cpu().numpy())
                val_labels.extend(y.cpu().numpy())
        val_acc = accuracy_score(val_labels, val_preds)

        print(f"Resume Epoch [{epoch+1:02d}/{EXTRA_EPOCHS}] "
              f"Train Acc: {train_acc:.4f} | Val Acc: {val_acc:.4f}")

    new_ckpt = f"hash_cnn_nist_resume_{EXTRA_EPOCHS}.pth"
    torch.save(model.state_dict(), new_ckpt)
    print(f"[INFO] 复训完成，新权重已保存为 {new_ckpt}")

# =========================
# 【改动】主入口
# =========================
if __name__ == "__main__":
    if RESUME:
        resume_train()
    else:
        train()